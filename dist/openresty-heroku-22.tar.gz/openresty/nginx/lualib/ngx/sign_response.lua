local resty_rsa = require "resty.rsa"
local resty_hmac = require "resty.hmac"
local resty_string = require "resty.string"

local _M = { _VERSION = '0.01' }

-- local rsa_public_key, rsa_priv_key, err = resty_rsa:generate_rsa_keys(2048)
local rsa_priv_key = [[-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEAuw4T755fepEyXTM66pzf6nv8NtnukQTMGnhmBFIFHp/P2vEp
xjXUBBDUpzKkVFR3wuK9O1FNmRDAGNGYC0N/9cZNdhykA1NixJfKQzncN31VJTmN
qJNZW0x7H9ZGoh2aE0zCCZpRlC1Rf5rL0SVlBoQkn/n9LnYFwyLLIK5/d/y/NZVL
6Z6Lcyvga0zRajamLIjY0Dy/8YIwVV6kaSsHeRv2cOB03eam6gbhLGIz/l8wuJhI
n1rOyJLQ36IOJymbbNmcC7+2hEQJP40qLvH7hZ1LaAkgQUHjfi8RvH2T1Jmce7XG
PxCoEd0yfeFz+pL1KeSWNey6cL3N5hJZE8EntQIDAQABAoIBAGim1ayIFK8EMQNH
uDyui/Aqcc9WWky0PGTK23irUsXxb1708gQ89WNY70Cj6qBrqZ1VMb3QHPP4FSFN
kh0rJJoi2g+ssm5R5r5KlhTKeFRrQInVC1Y3KhUUUwZa4aWtnhgSJ7Urq1yVhjU4
K7PVkhH1OHBwcp/d1Bd6jd65AgPkY63P+WpcARJkClmQ1RhgoRwThyJdpKrV4/gO
ha0AUGlJNRNvRwiZxP0zaI5C8RdrG96SnVpeYOcD0z/M1HVlkoYMXsXLKttwLfpK
88Igtm6ZJwRpfuMF5VA+9hHaYGCBdGz0B/rMp2fc+EtrOavYQGrWIWi2RL1Qk6Rt
BUyeTgECgYEA9anj4n/cak1MT+hbNFsL31mJXryl1eVNjEZj/iPMztpdS15CmFgj
Kjr9UuintjSiK7Is43nZUWWyP1XQjRhVi2uP7PRIv92QNl/YteWD6tYCInJHKe2J
QqYyZrElezsdayXb5DK6bi1UIYYji90g79N7x6pOR0UnQNQUXTv+Y8ECgYEAwuzl
6Ez4BSXIIL9NK41jfNMa73Utfl5oO1f6mHM2KbILqaFE76PSgEeXDbOKdcjCbbqC
KCGjwyPd+Clehg4vkYXTq1y2SQGHwfz7DilPSOxhPY9ND7lGbeNzDUK4x8xe52hd
MWKdgqeqCK83e5D0ihzRiMah8dbxmlfLAOZ3sPUCgYEA0dT9Czg/YqUHq7FCReQG
rg3iYgMsexjTNh/hxO97PqwRyBCJPWr7DlU4j5qdteobIsubv+kSEI6Ww7Ze3kWM
u/tyAeleQlPTnD4d8rBKD0ogpJ+L3WpBNaaToldpNmr149GAktgpmXYqSEA1GIAW
ZAL11UPIfOO6dYswobpevYECgYEApSosSODnCx2PbMgL8IpWMU+DNEF6sef2s8oB
aam9zCi0HyCqE9AhLlb61D48ZT8eF/IAFVcjttauX3dWQ4rDna/iwgHF5yhnyuS8
KayxJJ4+avYAmwEnfzdJpoPRpGI0TCovRQhFZI8C0Wb+QTJ7Mofmt9lvIUc64sff
GD0wT/0CgYASMf708dmc5Bpzcis++EgMJVb0q+ORmWzSai1NB4bf3LsNS6suWNNU
zj/JGtMaGvQo5vzGU4exNkhpQo8yUU5YbHlA8RCj7SYkmP78kCewEqxlx7dbcuj2
LAPWpiDca8StTfEphoKEVfCPHaUk0MlBHR4lCrnAkEtz23vhZKWhFw==
-----END RSA PRIVATE KEY-----]]
    --[[
    -----BEGIN RSA PUBLIC KEY-----
    MIIBCgKCAQEAuw4T755fepEyXTM66pzf6nv8NtnukQTMGnhmBFIFHp/P2vEpxjXU
    BBDUpzKkVFR3wuK9O1FNmRDAGNGYC0N/9cZNdhykA1NixJfKQzncN31VJTmNqJNZ
    W0x7H9ZGoh2aE0zCCZpRlC1Rf5rL0SVlBoQkn/n9LnYFwyLLIK5/d/y/NZVL6Z6L
    cyvga0zRajamLIjY0Dy/8YIwVV6kaSsHeRv2cOB03eam6gbhLGIz/l8wuJhIn1rO
    yJLQ36IOJymbbNmcC7+2hEQJP40qLvH7hZ1LaAkgQUHjfi8RvH2T1Jmce7XGPxCo
    Ed0yfeFz+pL1KeSWNey6cL3N5hJZE8EntQIDAQAB
    -----END RSA PUBLIC KEY-----
    ]]--
    --[[
    -----BEGIN RSA PRIVATE KEY-----
    MIIEpAIBAAKCAQEAuw4T755fepEyXTM66pzf6nv8NtnukQTMGnhmBFIFHp/P2vEp
    xjXUBBDUpzKkVFR3wuK9O1FNmRDAGNGYC0N/9cZNdhykA1NixJfKQzncN31VJTmN
    qJNZW0x7H9ZGoh2aE0zCCZpRlC1Rf5rL0SVlBoQkn/n9LnYFwyLLIK5/d/y/NZVL
    6Z6Lcyvga0zRajamLIjY0Dy/8YIwVV6kaSsHeRv2cOB03eam6gbhLGIz/l8wuJhI
    n1rOyJLQ36IOJymbbNmcC7+2hEQJP40qLvH7hZ1LaAkgQUHjfi8RvH2T1Jmce7XG
    PxCoEd0yfeFz+pL1KeSWNey6cL3N5hJZE8EntQIDAQABAoIBAGim1ayIFK8EMQNH
    uDyui/Aqcc9WWky0PGTK23irUsXxb1708gQ89WNY70Cj6qBrqZ1VMb3QHPP4FSFN
    kh0rJJoi2g+ssm5R5r5KlhTKeFRrQInVC1Y3KhUUUwZa4aWtnhgSJ7Urq1yVhjU4
    K7PVkhH1OHBwcp/d1Bd6jd65AgPkY63P+WpcARJkClmQ1RhgoRwThyJdpKrV4/gO
    ha0AUGlJNRNvRwiZxP0zaI5C8RdrG96SnVpeYOcD0z/M1HVlkoYMXsXLKttwLfpK
    88Igtm6ZJwRpfuMF5VA+9hHaYGCBdGz0B/rMp2fc+EtrOavYQGrWIWi2RL1Qk6Rt
    BUyeTgECgYEA9anj4n/cak1MT+hbNFsL31mJXryl1eVNjEZj/iPMztpdS15CmFgj
    Kjr9UuintjSiK7Is43nZUWWyP1XQjRhVi2uP7PRIv92QNl/YteWD6tYCInJHKe2J
    QqYyZrElezsdayXb5DK6bi1UIYYji90g79N7x6pOR0UnQNQUXTv+Y8ECgYEAwuzl
    6Ez4BSXIIL9NK41jfNMa73Utfl5oO1f6mHM2KbILqaFE76PSgEeXDbOKdcjCbbqC
    KCGjwyPd+Clehg4vkYXTq1y2SQGHwfz7DilPSOxhPY9ND7lGbeNzDUK4x8xe52hd
    MWKdgqeqCK83e5D0ihzRiMah8dbxmlfLAOZ3sPUCgYEA0dT9Czg/YqUHq7FCReQG
    rg3iYgMsexjTNh/hxO97PqwRyBCJPWr7DlU4j5qdteobIsubv+kSEI6Ww7Ze3kWM
    u/tyAeleQlPTnD4d8rBKD0ogpJ+L3WpBNaaToldpNmr149GAktgpmXYqSEA1GIAW
    ZAL11UPIfOO6dYswobpevYECgYEApSosSODnCx2PbMgL8IpWMU+DNEF6sef2s8oB
    aam9zCi0HyCqE9AhLlb61D48ZT8eF/IAFVcjttauX3dWQ4rDna/iwgHF5yhnyuS8
    KayxJJ4+avYAmwEnfzdJpoPRpGI0TCovRQhFZI8C0Wb+QTJ7Mofmt9lvIUc64sff
    GD0wT/0CgYASMf708dmc5Bpzcis++EgMJVb0q+ORmWzSai1NB4bf3LsNS6suWNNU
    zj/JGtMaGvQo5vzGU4exNkhpQo8yUU5YbHlA8RCj7SYkmP78kCewEqxlx7dbcuj2
    LAPWpiDca8StTfEphoKEVfCPHaUk0MlBHR4lCrnAkEtz23vhZKWhFw==
    -----END RSA PRIVATE KEY-----
    ]]--
local algo = resty_hmac.ALGOS.SHA512
local algo_str = "sha-512"
local secret_key = "" -- salt

local function get_full_response()
    local chunk, eof = ngx.arg[1], ngx.arg[2]
    local buffer = ngx.ctx.buffer or ""
    
    if eof then
        -- Finalize the buffer with last chunk (if any)
        local complete_body = buffer .. (chunk or "")
        -- Replace the body with the complete signed body
        ngx.arg[1] = complete_body
    else
        -- Accumulate chunks into the buffer
        ngx.ctx.buffer = buffer .. (chunk or "")
        -- Prevent partial response body from being sent to client
        ngx.arg[1] = nil
    end
    return ngx.arg[1]
end

local function do_hmac(data)
    -- Calculate the signature
    local hmac = resty_hmac:new(secret_key, algo)
    if not hmac then
        ngx.say("failed to create the hmac object")
        return
    end
    local ok = hmac:update(data)
    if not ok then
        ngx.say("failed to add data")
        return
    end

    local mac = hmac:final()  -- binary mac

    -- dont forget to reset after final!
    if not hmac:reset() then
        ngx.say("failed to reset hmac")
        return
    end

    return mac
end

local function hmac_hex(data)
    return resty_string.to_hex(do_hmac(data))
end

local function get_content_digest_from_cache(my_cache)
    local key = hmac_hex(ngx.var.request_uri)
    local content_digest = my_cache:get(key)
    my_cache:delete(key)
    return algo_str .. "=:" .. ngx.encode_base64(content_digest) .. ":"
end

local function sign(signing_string)
    local secret_key = "your_secret_key"
    -- Trim the trailing newline
    signing_string = signing_string:sub(1, -2)
    -- ngx.say("signing_string: ", signing_string)
    -- Calculate the signature
    local algorithm = "SHA256"
    local priv, err = resty_rsa:new({ private_key = rsa_priv_key, algorithm = algorithm })
    if not priv then
        ngx.say("new rsa err: ", err)
        return
    end
    local digest = do_hmac(signing_string);
    -- ngx.say("digest:", resty_string.to_hex(digest))
    local sig, err = priv:sign(digest)
    if not sig then
        ngx.say("failed to sign:", err)
        return
    end
    return sig
end

function _M.save_content_digest_into_cache(self, my_cache)
    local response = get_full_response()
    if response then
        local digest = do_hmac(response)
        local key = hmac_hex(ngx.var.request_uri)
        my_cache:set(key, digest)
    end
end

function _M.add_signature(self, my_cache)
    local content_digest = get_content_digest_from_cache(my_cache)
    if content_digest then
        ngx.header["Content-Digest"] = content_digest
        local timestamp = os.time()
        local keyid = "RSA (X.509 preloaded)"
        local alg = "rsa-pss-sha512"
        local sig_input = 'sig=("@status" "@method" "@authority" "@path" "content-digest" "content-length" "content-type");alg="' .. alg .. '";created=' .. timestamp .. ';keyid="' .. keyid .. '"'
        ngx.header["Signature-Input"] = sig_input

        local status = tostring(ngx.status)
        local method = tostring(ngx.method)
        local authority = tostring(ngx.authority)
        local path = tostring(ngx.path)
        local content_length = ngx.header["Content-Length"] or ""
        local content_type = ngx.header["Content-Type"] or ""
        local sig_input_data = 'sig=("' .. status .. '" "' .. method .. '" "' .. authority .. '" "' .. path .. '" "' .. content_digest .. '" "' .. content_length .. '" "' .. content_type .. '");alg="' .. alg .. '";created=' .. timestamp .. ';keyid="' .. keyid .. '"'
        -- sign data
        local sig = sign(sig_input_data)
        -- base64
        local sig_base64 = ngx.encode_base64(sig)

        ngx.header["Signature"] = "sig=:" .. sig_base64 .. ":"
    end
end

function _M.get_cookie(self, key)
    local cookies = ngx.var.http_cookie
                
    -- Check if the cookies string is not empty or nil
    if cookies then
        -- Pattern to extract a specific cookie named "MyCookieName"
        local pattern = key .. "=([^;]+)"
        -- Use string.match to search for MyCookieName and capture its value
        local cookie_value = string.match(cookies, pattern)
        return cookie_value
    else
        return nil
    end
end

return _M
